var _mokka_tutorial =
[
    [ "Create a cycle definition", "_mokka_tutorial__create_cycle_definition.html", null ],
    [ "Add/Remove an event", "_mokka_tutorial__add_remove_event.html", [
      [ "Add event", "_mokka_tutorial__add_remove_event.html#MokkaTutorial_AddEventSubSection", null ],
      [ "Remove event", "_mokka_tutorial__add_remove_event.html#MokkaTutorial_RemoveEventSubSection", null ]
    ] ],
    [ "Edit an event", "_mokka_tutorial__edit_event.html", null ],
    [ "Change color of marker", "_mokka_tutorial__change_color_marker.html", null ],
    [ "Create new segment", "_mokka_tutorial__create_new_segment.html", null ],
    [ "Create/Save configuration", "_mokka_tutorial__create_save_new_configuration.html", null ],
    [ "Watch videos", "_mokka_tutorial__watch_video.html", null ]
];