var _mokka_menu_bar =
[
    [ "File", "_mokka_menu_bar.html#MokkaMenuBarFile", null ],
    [ "Edit", "_mokka_menu_bar.html#MokkaMenuBarEdit", null ],
    [ "View", "_mokka_menu_bar.html#MokkaMenuView", null ],
    [ "Settings", "_mokka_menu_bar.html#MokkaMenuBarSettings", null ],
    [ "Tools", "_mokka_menu_bar.html#MokkaMenuBarTools", null ],
    [ "Window", "_mokka_menu_bar.html#MokkaMenuBarWindow", null ],
    [ "Help", "_mokka_menu_bar.html#MokkaMenuHelp", null ],
    [ "Import Assistant", "_mokka_import_assistant.html", [
      [ "Rules to merge/concatenate acquisitions", "_mokka_import_assistant.html#MokkaImportAssistantRules", null ]
    ] ]
];